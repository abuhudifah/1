/**
 * components/AccountManagementComponent.js — v2.0
 * إصلاحات:
 * 1. عرض دليل حسابات شجري باستخدام get_chart_of_accounts
 * 2. كشف حساب احترافي باستخدام get_account_statement
 * 3. تصنيف واضح: مندوبون / شركات / بنوك / مصروفات / خزينة
 * 4. عرض الرصيد الافتتاحي والختامي والرصيد الجاري
 * 5. طباعة احترافية
 */
'use strict';

const AccountManagementComponent = {
  _selectedAccount    : null,
  _selectedAccountName: null,

  async render(container) {
    if (!AuthService.isAdmin() && !AuthService.isAdminAssistant()) {
      container.innerHTML = `<div class="empty-state">
        <div class="empty-state-icon">🔒</div>
        <div class="empty-state-text">إدارة الحسابات للمدير والمساعد الإداري فقط</div></div>`;
      return;
    }

    container.innerHTML = '';
    const wrap = document.createElement('div');

    // العنوان
    const titleRow = document.createElement('div');
    titleRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:8px;';
    titleRow.innerHTML = `
      <h2 style="font-size:1.2rem;font-weight:700;color:var(--text-primary);">📊 دليل الحسابات المحاسبية</h2>
      <button id="acct-refresh-btn" class="btn btn-secondary btn-sm" style="display:flex;align-items:center;gap:4px;">
        <i data-lucide="refresh-cw" style="width:13px;height:13px;"></i> تحديث
      </button>`;
    wrap.appendChild(titleRow);

    // حاوية دليل الحسابات
    const chartEl = document.createElement('div');
    chartEl.id = 'acct-chart';
    chartEl.innerHTML = `
      ${['للمندوبين','للشركات','للبنوك','للمصروفات'].map(n=>`
        <div class="glass-card" style="margin-bottom:16px;">
          <div class="skeleton" style="height:32px;border-radius:8px;margin-bottom:12px;"></div>
          <div class="skeleton" style="height:44px;border-radius:8px;margin-bottom:8px;"></div>
          <div class="skeleton" style="height:44px;border-radius:8px;"></div>
        </div>`).join('')}`;
    wrap.appendChild(chartEl);

    // كشف الحساب (مخفي افتراضياً)
    const stmtSection = document.createElement('div');
    stmtSection.id = 'acct-stmt-section';
    stmtSection.style.display = 'none';
    stmtSection.innerHTML = `
      <div class="glass-card" style="margin-bottom:16px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px;">
          <div>
            <h3 style="font-size:1rem;font-weight:700;color:var(--text-primary);" id="stmt-account-title">📄 كشف الحساب</h3>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;" id="stmt-account-id"></p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button id="stmt-print-btn" class="btn btn-secondary btn-sm">
              <i data-lucide="printer" style="width:13px;height:13px;"></i> طباعة
            </button>
            <button id="stmt-close-btn" class="btn btn-secondary btn-sm" style="color:var(--danger);">✕ إغلاق</button>
          </div>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px;align-items:flex-end;">
          <div class="form-group" style="margin:0;flex:1;min-width:120px;">
            <label class="form-label" style="font-size:0.78rem;">من تاريخ</label>
            <input id="stmt-from" type="date" class="form-control" style="padding:7px;font-size:0.85rem;">
          </div>
          <div class="form-group" style="margin:0;flex:1;min-width:120px;">
            <label class="form-label" style="font-size:0.78rem;">إلى تاريخ</label>
            <input id="stmt-to" type="date" class="form-control" style="padding:7px;font-size:0.85rem;"
              value="${getCurrentSaudiDate()}">
          </div>
          <button id="stmt-load-btn" class="btn btn-primary btn-sm">عرض الكشف</button>
        </div>
        <div id="stmt-summary" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:16px;"></div>
        <div id="stmt-entries"></div>
      </div>`;
    wrap.appendChild(stmtSection);

    container.appendChild(wrap);

    // ربط الأحداث
    document.getElementById('acct-refresh-btn')?.addEventListener('click',()=>this._loadChart());
    document.getElementById('stmt-load-btn')?.addEventListener('click',()=>this._loadStatement());
    document.getElementById('stmt-close-btn')?.addEventListener('click',()=>{
      stmtSection.style.display='none';
      this._selectedAccount=null;
    });
    document.getElementById('stmt-print-btn')?.addEventListener('click',()=>window.print());

    if (window.lucide) lucide.createIcons();
    await this._loadChart();
  },

  // ─── تحميل دليل الحسابات ───
  async _loadChart() {
    const el = document.getElementById('acct-chart');
    if (!el) return;

    el.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;padding:40px;"><div class="spinner spinner-dark"></div></div>`;

    let chartData = null;

    try {
      if (navigator.onLine) {
        const { data, error } = await supabaseClient.rpc('get_chart_of_accounts');
        if (!error && data) chartData = data;
      }
    } catch(e) { console.error('Chart of accounts error:', e); }

    // Fallback: قراءة من account_balances مباشرة
    if (!chartData) {
      chartData = await this._buildLocalChartData();
    }

    if (!chartData || !chartData.categories) {
      el.innerHTML=`<div class="empty-state"><div class="empty-state-icon">📒</div><div class="empty-state-text">لا توجد حسابات</div></div>`;
      return;
    }

    el.innerHTML = '';

    const categoryMeta = {
      agents   : { icon:'👤', label:'حسابات المناديب',          color:'var(--accent)' },
      companies : { icon:'🏢', label:'حسابات الشركات',           color:'var(--info)'   },
      banks     : { icon:'🏦', label:'الحسابات البنكية',          color:'var(--success)'},
      expenses  : { icon:'💸', label:'حسابات المصروفات',          color:'var(--danger)' },
      treasury  : { icon:'🏛️',label:'الخزينة والحسابات العامة',  color:'var(--warning)'},
    };

    for (const cat of (chartData.categories || [])) {
      const meta   = categoryMeta[cat.category] || { icon:'📋', label:cat.label||cat.category, color:'var(--text-secondary)' };
      const total  = Math.round(parseFloat(cat.total_balance||0));
      const accounts = cat.accounts || [];

      const section = document.createElement('div');
      section.className = 'glass-card';
      section.style.marginBottom = '16px';

      // رأس التصنيف
      const header = document.createElement('div');
      header.style.cssText = `
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:14px;padding-bottom:12px;
        border-bottom:2px solid ${meta.color}30;`;
      header.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="
            width:38px;height:38px;border-radius:10px;
            background:${meta.color}18;
            display:flex;align-items:center;justify-content:center;
            font-size:1.2rem;">
            ${meta.icon}
          </div>
          <div>
            <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);">${escapeHtml(meta.label)}</div>
            <div style="font-size:0.75rem;color:var(--text-muted);">${accounts.length} حساب</div>
          </div>
        </div>
        <div style="text-align:left;direction:ltr;">
          <div style="font-weight:800;font-size:1.1rem;color:${meta.color};">
            ${total>=0?'':'−'}${Math.abs(total).toLocaleString('en-US')}
            <span style="font-size:0.65rem;font-weight:500;color:var(--text-muted);">${APP_CONFIG.CURRENCY_SYMBOL}</span>
          </div>
          <div style="font-size:0.72rem;color:var(--text-muted);">إجمالي الرصيد</div>
        </div>`;
      section.appendChild(header);

      // قائمة الحسابات
      if (!accounts.length) {
        section.innerHTML += `<div style="color:var(--text-muted);font-size:0.85rem;padding:8px 0;">لا توجد حسابات</div>`;
      } else {
        const table = document.createElement('div');
        table.className = 'table-wrapper';
        table.innerHTML = `
          <table class="data-table">
            <thead><tr>
              <th>الحساب</th>
              <th>معرف الحساب</th>
              <th>الرصيد</th>
              <th>كشف</th>
            </tr></thead>
            <tbody>
              ${accounts.map(acc=>{
                const bal = Math.round(parseFloat(acc.balance||0));
                return `<tr>
                  <td style="font-weight:600;font-size:0.88rem;">${escapeHtml(acc.name||acc.account_id)}</td>
                  <td style="direction:ltr;font-family:monospace;font-size:0.72rem;color:var(--text-muted);">
                    ${escapeHtml(acc.account_id)}
                  </td>
                  <td style="font-weight:700;color:${bal>=0?'var(--success)':'var(--danger)'};direction:ltr;">
                    ${bal>=0?'':'−'}${Math.abs(bal).toLocaleString('en-US')} ر.س
                  </td>
                  <td>
                    <button class="btn btn-secondary btn-sm view-stmt-btn"
                      data-account="${escapeHtml(acc.account_id)}"
                      data-name="${escapeHtml(acc.name||acc.account_id)}"
                      style="display:flex;align-items:center;gap:4px;font-size:0.78rem;">
                      <i data-lucide="file-text" style="width:12px;height:12px;"></i>
                      كشف
                    </button>
                  </td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>`;
        section.appendChild(table);
      }

      el.appendChild(section);
    }

    // إجمالي الأصول والخصوم
    if (chartData.total_assets !== undefined) {
      const summaryCard = document.createElement('div');
      summaryCard.className = 'glass-card';
      summaryCard.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:16px;';
      summaryCard.innerHTML = `
        <div style="text-align:center;padding:12px;background:rgba(5,150,105,0.08);border-radius:12px;border:1px solid rgba(5,150,105,0.15);">
          <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:4px;">إجمالي الأرصدة الدائنة (المدينون)</div>
          <div style="font-size:1.3rem;font-weight:800;color:var(--success);direction:ltr;">
            ${Math.round(parseFloat(chartData.total_assets||0)).toLocaleString('en-US')} ر.س
          </div>
        </div>
        <div style="text-align:center;padding:12px;background:rgba(220,38,38,0.08);border-radius:12px;border:1px solid rgba(220,38,38,0.15);">
          <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:4px;">إجمالي الأرصدة المدينة (الالتزامات)</div>
          <div style="font-size:1.3rem;font-weight:800;color:var(--danger);direction:ltr;">
            ${Math.round(parseFloat(chartData.total_liabilities||0)).toLocaleString('en-US')} ر.س
          </div>
        </div>`;
      el.appendChild(summaryCard);
    }

    // ربط أزرار الكشف
    el.querySelectorAll('.view-stmt-btn').forEach(btn=>{
      btn.addEventListener('click',()=>this._showStatement(btn.dataset.account, btn.dataset.name));
    });

    if (window.lucide) lucide.createIcons();
  },

  // ─── بناء بيانات محلية للـ fallback ───
  async _buildLocalChartData() {
    let balances = [];
    try {
      const { data } = await supabaseClient.from('account_balances').select('*').order('account_id');
      balances = data||[];
    } catch {
      balances = await db.account_balances.toArray();
    }
    if (!balances.length) return null;

    const users     = AppStore.getState('users');
    const banks     = AppStore.getState('bankAccounts');
    const companies = AppStore.getState('companies');

    const cats = { agents:[], companies:[], banks:[], expenses:[], treasury:[] };

    for (const b of balances) {
      const bal = Math.round(parseFloat(b.balance||0));
      let name = b.account_id;
      let cat  = 'treasury';

      if (b.account_id.startsWith('AGT_')) {
        const id = b.account_id.slice(4);
        const u  = users.find(u=>u.id===id);
        name = u?.display_name || id;
        cat  = 'agents';
      } else if (b.account_id.startsWith('COMP_')) {
        const prefix = b.account_id.slice(5);
        const c = companies.find(c=>c.account_prefix===prefix);
        name = c?.name || prefix;
        cat  = 'companies';
      } else if (b.account_id.startsWith('BNK_')) {
        const id = b.account_id.slice(4);
        const bk = banks.find(bk=>bk.id===id);
        name = bk?.name || id;
        cat  = 'banks';
      } else if (b.account_id.startsWith('EXP_')) {
        name = b.account_id.slice(4);
        cat  = 'expenses';
      }

      cats[cat].push({ account_id: b.account_id, name, balance: bal });
    }

    return {
      categories: Object.entries(cats).map(([key,accs])=>({
        category: key,
        label: {agents:'المناديب',companies:'الشركات',banks:'البنوك',expenses:'المصروفات',treasury:'الخزينة'}[key]||key,
        total_balance: accs.reduce((s,a)=>s+a.balance,0),
        accounts: accs,
      })).filter(c=>c.accounts.length>0),
    };
  },

  // ─── عرض كشف الحساب ───
  _showStatement(accountId, accountName) {
    this._selectedAccount     = accountId;
    this._selectedAccountName = accountName;

    const stmtSection = document.getElementById('acct-stmt-section');
    if (stmtSection) stmtSection.style.display = 'block';

    const titleEl = document.getElementById('stmt-account-title');
    const idEl    = document.getElementById('stmt-account-id');
    if (titleEl) titleEl.textContent = `📄 كشف حساب: ${accountName}`;
    if (idEl)    idEl.textContent    = accountId;

    // تعيين تاريخ افتراضي: أول الشهر
    const firstOfMonth = new Date();
    firstOfMonth.setDate(1);
    const fromDefault = firstOfMonth.toLocaleDateString('en-CA',{timeZone:APP_CONFIG.TIMEZONE});
    const fromEl = document.getElementById('stmt-from');
    if (fromEl && !fromEl.value) fromEl.value = fromDefault;

    stmtSection.scrollIntoView({ behavior:'smooth', block:'start' });
    this._loadStatement();
  },

  // ─── تحميل قيود الكشف ───
  async _loadStatement() {
    if (!this._selectedAccount) return;
    const entriesEl = document.getElementById('stmt-entries');
    const summaryEl = document.getElementById('stmt-summary');
    if (!entriesEl) return;

    const from = document.getElementById('stmt-from')?.value || '2020-01-01';
    const to   = document.getElementById('stmt-to')?.value   || getCurrentSaudiDate();

    entriesEl.innerHTML = `<div class="skeleton" style="height:44px;border-radius:8px;margin-bottom:6px;"></div>`.repeat(4);
    if (summaryEl) summaryEl.innerHTML = '';

    let stmtData = null;

    try {
      if (navigator.onLine) {
        const { data, error } = await supabaseClient.rpc('get_account_statement', {
          p_account_id : this._selectedAccount,
          p_from_date  : from,
          p_to_date    : to,
        });
        if (!error && data) stmtData = data;
      }
    } catch(e) { console.error('Statement error:', e); }

    // Fallback إلى AccountingService
    if (!stmtData) {
      const result = await AccountingService.getStatement(this._selectedAccount, from, to, { page:1, pageSize:500 });
      if (isOk(result)) {
        stmtData = {
          opening_balance : result.data.openingBalance,
          closing_balance : result.data.closingBalance,
          total_debit     : result.data.totalDebit,
          total_credit    : result.data.totalCredit,
          entries         : result.data.entries,
          entries_count   : result.data.entries.length,
        };
      }
    }

    if (!stmtData) {
      entriesEl.innerHTML=`<div class="empty-state"><div class="empty-state-text">فشل تحميل كشف الحساب</div></div>`;
      return;
    }

    // ملخص الأرقام
    const openingBal = Math.round(parseFloat(stmtData.opening_balance||0));
    const closingBal = Math.round(parseFloat(stmtData.closing_balance||0));
    const totalDebit = Math.round(parseFloat(stmtData.total_debit||0));
    const totalCred  = Math.round(parseFloat(stmtData.total_credit||0));

    if (summaryEl) {
      summaryEl.innerHTML = `
        <div style="text-align:center;padding:12px;background:var(--bg-hover);border-radius:12px;border:1px solid var(--border-color);">
          <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:4px;">الرصيد الافتتاحي</div>
          <div style="font-weight:800;font-size:1rem;color:var(--info);direction:ltr;">
            ${openingBal>=0?'':'−'}${Math.abs(openingBal).toLocaleString('en-US')} ر.س
          </div>
        </div>
        <div style="text-align:center;padding:12px;background:rgba(5,150,105,0.08);border-radius:12px;border:1px solid rgba(5,150,105,0.15);">
          <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:4px;">إجمالي المدين</div>
          <div style="font-weight:800;font-size:1rem;color:var(--success);direction:ltr;">
            ${totalDebit.toLocaleString('en-US')} ر.س
          </div>
        </div>
        <div style="text-align:center;padding:12px;background:rgba(220,38,38,0.08);border-radius:12px;border:1px solid rgba(220,38,38,0.15);">
          <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:4px;">إجمالي الدائن</div>
          <div style="font-weight:800;font-size:1rem;color:var(--danger);direction:ltr;">
            ${totalCred.toLocaleString('en-US')} ر.س
          </div>
        </div>
        <div style="text-align:center;padding:12px;background:${closingBal>=0?'rgba(5,150,105,0.10)':'rgba(220,38,38,0.10)'};border-radius:12px;border:1px solid ${closingBal>=0?'rgba(5,150,105,0.20)':'rgba(220,38,38,0.20)'};">
          <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:4px;">الرصيد الختامي</div>
          <div style="font-weight:800;font-size:1rem;color:${closingBal>=0?'var(--success)':'var(--danger)'};direction:ltr;">
            ${closingBal>=0?'':'−'}${Math.abs(closingBal).toLocaleString('en-US')} ر.س
          </div>
        </div>`;
    }

    const entries = stmtData.entries || [];
    if (!entries.length) {
      entriesEl.innerHTML = `<div class="empty-state">
        <div class="empty-state-icon">📄</div>
        <div class="empty-state-text">لا توجد قيود في هذه الفترة</div></div>`;
      return;
    }

    // حساب الرصيد الجاري
    let runningBal = openingBal;
    const table = document.createElement('div');
    table.className = 'table-wrapper';
    table.innerHTML = `
      <table class="data-table">
        <thead><tr>
          <th>التاريخ</th>
          <th>رقم القيد</th>
          <th>البيان</th>
          <th>المندوب</th>
          <th>مدين</th>
          <th>دائن</th>
          <th>الرصيد</th>
        </tr></thead>
        <tbody>
          <tr style="background:rgba(2,132,199,0.06);">
            <td colspan="6" style="font-weight:700;color:var(--info);">رصيد افتتاحي</td>
            <td style="font-weight:800;color:var(--info);direction:ltr;">
              ${openingBal>=0?'':'−'}${Math.abs(openingBal).toLocaleString('en-US')} ر.س
            </td>
          </tr>
          ${entries.map(e=>{
            const d = Math.round(parseFloat(e.debit||0));
            const c = Math.round(parseFloat(e.credit||0));
            runningBal += d - c;
            return `<tr>
              <td style="font-size:0.82rem;white-space:nowrap;">${escapeHtml(formatDateArabic(e.date))}</td>
              <td style="font-family:monospace;font-size:0.72rem;color:var(--text-muted);direction:ltr;">
                ${escapeHtml(e.voucher_number||'—')}
              </td>
              <td style="font-size:0.85rem;max-width:180px;overflow:hidden;text-overflow:ellipsis;">
                ${escapeHtml(e.description||'—')}
              </td>
              <td style="font-size:0.80rem;color:var(--text-secondary);">${escapeHtml(e.agent_name||'—')}</td>
              <td style="color:var(--success);font-weight:${d>0?'700':'400'};direction:ltr;">
                ${d>0?d.toLocaleString('en-US')+' ر.س':'—'}
              </td>
              <td style="color:var(--danger);font-weight:${c>0?'700':'400'};direction:ltr;">
                ${c>0?c.toLocaleString('en-US')+' ر.س':'—'}
              </td>
              <td style="font-weight:700;color:${runningBal>=0?'var(--success)':'var(--danger)'};direction:ltr;">
                ${runningBal>=0?'':'−'}${Math.abs(runningBal).toLocaleString('en-US')} ر.س
              </td>
            </tr>`;
          }).join('')}
          <tr style="background:rgba(5,150,105,0.06);border-top:2px solid var(--success)30;">
            <td colspan="6" style="font-weight:700;color:${closingBal>=0?'var(--success)':'var(--danger)'};">رصيد ختامي</td>
            <td style="font-weight:800;color:${closingBal>=0?'var(--success)':'var(--danger)'};direction:ltr;">
              ${closingBal>=0?'':'−'}${Math.abs(closingBal).toLocaleString('en-US')} ر.س
            </td>
          </tr>
        </tbody>
      </table>`;
    entriesEl.innerHTML = '';
    entriesEl.appendChild(table);

    if (window.lucide) lucide.createIcons();
  },
};

window.AccountManagementComponent = AccountManagementComponent;
console.log('✅ AccountManagementComponent v2.0 محمّل — دليل حسابات شجري مع كشف احترافي');
