#!/bin/bash
# ادخل توكنك هنا
GITHUB_TOKEN="YOUR_GITHUB_TOKEN_HERE"
REPO="abuhudifah/1"
BRANCH="main"

upload_file() {
  local path="$1"
  local local_file="$2"
  SHA=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
    "https://api.github.com/repos/$REPO/contents/$path?ref=$BRANCH" | \
    python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('sha',''))" 2>/dev/null)
  CONTENT=$(base64 -w0 "$local_file")
  if [ -n "$SHA" ]; then
    BODY="{\"message\":\"fix: update $path\",\"content\":\"$CONTENT\",\"sha\":\"$SHA\",\"branch\":\"$BRANCH\"}"
  else
    BODY="{\"message\":\"feat: add $path\",\"content\":\"$CONTENT\",\"branch\":\"$BRANCH\"}"
  fi
  RES=$(curl -s -X PUT "https://api.github.com/repos/$REPO/contents/$path" \
    -H "Authorization: token $GITHUB_TOKEN" \
    -H "Content-Type: application/json" -d "$BODY")
  echo "$path: $(echo $RES | python3 -c "import json,sys; d=json.load(sys.stdin); print('OK' if 'content' in d else d.get('message','ERR'))" 2>/dev/null)"
}

upload_file "components/LoginComponent.js"              "components/LoginComponent.js"
upload_file "components/DashboardComponent.js"          "components/DashboardComponent.js"
upload_file "components/AuditLogComponent.js"           "components/AuditLogComponent.js"
upload_file "components/AccountManagementComponent.js"  "components/AccountManagementComponent.js"
upload_file "components/AllOperationsComponent.js"      "components/AllOperationsComponent.js"

# دمج CSS الإضافي
CURR_CSS=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$REPO/contents/assets/css/styles.css?ref=$BRANCH")
CURR_SHA=$(echo $CURR_CSS | python3 -c "import json,sys; print(json.load(sys.stdin).get('sha',''))" 2>/dev/null)
CURR_CONTENT=$(echo $CURR_CSS | python3 -c "import json,sys,base64; print(base64.b64decode(json.load(sys.stdin)['content']).decode())" 2>/dev/null)

# دمج CSS الجديد مع الحالي
NEW_CSS="${CURR_CONTENT}
$(cat assets/css/styles_additions.css)"

NEW_ENCODED=$(echo "$NEW_CSS" | base64 -w0)
curl -s -X PUT "https://api.github.com/repos/$REPO/contents/assets/css/styles.css" \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"improve: add CSS enhancements\",\"content\":\"$NEW_ENCODED\",\"sha\":\"$CURR_SHA\",\"branch\":\"$BRANCH\"}" | \
  python3 -c "import json,sys; d=json.load(sys.stdin); print('assets/css/styles.css: '+ ('OK' if 'content' in d else d.get('message','ERR')))" 2>/dev/null

# تحديث config.js بإضافة RPC الجديدة
CURR_CONFIG=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$REPO/contents/config.js?ref=$BRANCH")
CONFIG_SHA=$(echo $CURR_CONFIG | python3 -c "import json,sys; print(json.load(sys.stdin).get('sha',''))" 2>/dev/null)
CONFIG_CONTENT=$(echo $CURR_CONFIG | python3 -c "import json,sys,base64; print(base64.b64decode(json.load(sys.stdin)['content']).decode())" 2>/dev/null)

# إضافة RPC في نهاية const RPC
NEW_CONFIG="${CONFIG_CONTENT}

// ═══ RPC الجديدة المضافة ═══
window.RPC = Object.freeze({
  ...RPC,
  GET_ADMIN_DASHBOARD   : 'get_admin_dashboard',
  GET_DAILY_SUMMARY     : 'get_daily_summary',
  GET_CHART_OF_ACCOUNTS : 'get_chart_of_accounts',
  GET_ACCOUNT_STATEMENT : 'get_account_statement',
  GET_BANK_STATEMENT    : 'get_bank_statement',
  GET_AUDIT_LOGS        : 'get_audit_logs',
});
"

CONFIG_ENCODED=$(echo "$NEW_CONFIG" | base64 -w0)
curl -s -X PUT "https://api.github.com/repos/$REPO/contents/config.js" \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"feat: add new RPC constants\",\"content\":\"$CONFIG_ENCODED\",\"sha\":\"$CONFIG_SHA\",\"branch\":\"$BRANCH\"}" | \
  python3 -c "import json,sys; d=json.load(sys.stdin); print('config.js: '+('OK' if 'content' in d else d.get('message','ERR')))" 2>/dev/null

echo "=== اكتمل الرفع ==="
