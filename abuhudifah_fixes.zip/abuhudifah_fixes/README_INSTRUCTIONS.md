# دليل تطبيق الإصلاحات

## الطريقة 1: رفع تلقائي عبر Script

1. افتح `upload_to_github.sh`
2. استبدل `YOUR_GITHUB_TOKEN_HERE` بتوكنك من: https://github.com/settings/tokens
3. نفّذ: `bash upload_to_github.sh`

## الطريقة 2: رفع يدوي

ارفع هذه الملفات إلى المستودع:

| الملف المحلي | المسار في GitHub |
|---|---|
| components/LoginComponent.js | components/LoginComponent.js |
| components/DashboardComponent.js | components/DashboardComponent.js |
| components/AuditLogComponent.js | components/AuditLogComponent.js |
| components/AccountManagementComponent.js | components/AccountManagementComponent.js |
| components/AllOperationsComponent.js | components/AllOperationsComponent.js |
| assets/css/styles_additions.css | **أضف محتواه في نهاية** assets/css/styles.css |

## التحديثات الواجب إضافتها يدوياً في config.js

أضف هذا في نهاية ملف `config.js`:

```javascript
// ═══ RPC الجديدة ═══
window.RPC = Object.freeze({
  ...RPC,
  GET_ADMIN_DASHBOARD   : 'get_admin_dashboard',
  GET_DAILY_SUMMARY     : 'get_daily_summary',
  GET_CHART_OF_ACCOUNTS : 'get_chart_of_accounts',
  GET_ACCOUNT_STATEMENT : 'get_account_statement',
  GET_BANK_STATEMENT    : 'get_bank_statement',
  GET_AUDIT_LOGS        : 'get_audit_logs',
});
```
